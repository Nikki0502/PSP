var searchData=
[
  ['savecontext_178',['saveContext',['../util_8h.html#a95d67df1cf6117ce43766d06b8113297',1,'util.h']]],
  ['schedulinginfo_179',['schedulingInfo',['../os__scheduling__strategies_8c.html#aadb0e3d669bbca5d4d424f4ba8724848',1,'os_scheduling_strategies.c']]],
  ['schedulinginformation_180',['SchedulingInformation',['../struct_scheduling_information.html',1,'SchedulingInformation'],['../os__scheduling__strategies_8h.html#a13aac67d6c5ae31dd05667417622ea64',1,'SchedulingInformation():&#160;os_scheduling_strategies.h']]],
  ['schedulingstrategy_181',['SchedulingStrategy',['../os__scheduler_8h.html#a19b2831a25a61b35337be0d5386f1098',1,'SchedulingStrategy():&#160;os_scheduler.h'],['../os__scheduler_8h.html#ac3ed7aa5fa89d4026cd86e4861ca7963',1,'SchedulingStrategy():&#160;os_scheduler.h']]],
  ['size_182',['size',['../struct_param_stack.html#a25e5b12c36cd8d34de1455d7483a7da9',1,'ParamStack']]],
  ['spos_20manual_183',['SPOS Manual',['../index.html',1,'']]],
  ['stack_5fsize_5fisr_184',['STACK_SIZE_ISR',['../defines_8h.html#a5897211c66fb513c0e45424e77446325',1,'defines.h']]],
  ['stack_5fsize_5fmain_185',['STACK_SIZE_MAIN',['../defines_8h.html#a0187f5405175817f5d15b70f2d5ba908',1,'defines.h']]],
  ['stack_5fsize_5fproc_186',['STACK_SIZE_PROC',['../defines_8h.html#a69935146762e044c13bc1e04e159ac7f',1,'defines.h']]],
  ['stackchecksum_187',['StackChecksum',['../os__process_8h.html#a45db48aaf651fca0006e612d9a3b4b9b',1,'os_process.h']]],
  ['stackpointer_188',['StackPointer',['../union_stack_pointer.html',1,'StackPointer'],['../os__process_8h.html#a52b6ead6aa07550bf81e7340e9d50e53',1,'StackPointer():&#160;os_process.h']]],
  ['success_189',['success',['../struct_page_result.html#a26ab3f163c9b9e0ab50d0325dac0b921',1,'PageResult']]]
];
