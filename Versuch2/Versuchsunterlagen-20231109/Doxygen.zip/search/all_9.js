var searchData=
[
  ['null_90',['NULL',['../defines_8h.html#a070d2ce7b6bb7e5c05602aa8c308d0c4',1,'defines.h']]]
];
