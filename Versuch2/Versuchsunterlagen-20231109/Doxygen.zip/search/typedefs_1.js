var searchData=
[
  ['priority_303',['Priority',['../os__process_8h.html#a1bb679f7ad1508e942e35da9a0e7eabf',1,'os_process.h']]],
  ['process_304',['Process',['../os__process_8h.html#a3b5b0413545e0d4ff600b0a7203e3086',1,'os_process.h']]],
  ['processid_305',['ProcessID',['../os__process_8h.html#a9ae6ab2a896fd7ccf2c04cd38f9fa6c9',1,'os_process.h']]],
  ['processstate_306',['ProcessState',['../os__process_8h.html#a188e89ad1abd0d38668fb83d89aa8891',1,'os_process.h']]],
  ['program_307',['Program',['../os__process_8h.html#a1855c0ea815dd2a3323638f2fda0c38a',1,'os_process.h']]]
];
