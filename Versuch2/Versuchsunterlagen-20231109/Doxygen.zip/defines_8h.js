var defines_8h =
[
    [ "BOTTOM_OF_ISR_STACK", "defines_8h.html#a095a6c4cd36580093b8ba8d800872492", null ],
    [ "BOTTOM_OF_MAIN_STACK", "defines_8h.html#ad5b1227070231857dcd8ecab7dc65ccd", null ],
    [ "BOTTOM_OF_PROCS_STACK", "defines_8h.html#af8d416e3d1bfda326bac2f2d63f5b6e0", null ],
    [ "DEFAULT_OUTPUT_DELAY", "defines_8h.html#ac3ca25394ded1ac297c6c5ae8ba51050", null ],
    [ "DEFAULT_PRIORITY", "defines_8h.html#a0756f011ef667460d583017366823244", null ],
    [ "INVALID_PROCESS", "defines_8h.html#a455404d0cf6e4ea0b53f9f747e3744b1", null ],
    [ "MAX_NUMBER_OF_PROCESSES", "defines_8h.html#a57c4c2d31ce05f6034d5356eb9e366f2", null ],
    [ "NULL", "defines_8h.html#a070d2ce7b6bb7e5c05602aa8c308d0c4", null ],
    [ "PROCESS_STACK_BOTTOM", "defines_8h.html#a5d7156541ae49491ce8c7c89dabf876a", null ],
    [ "STACK_SIZE_ISR", "defines_8h.html#a5897211c66fb513c0e45424e77446325", null ],
    [ "STACK_SIZE_MAIN", "defines_8h.html#a0187f5405175817f5d15b70f2d5ba908", null ],
    [ "STACK_SIZE_PROC", "defines_8h.html#a69935146762e044c13bc1e04e159ac7f", null ],
    [ "VERSUCH", "defines_8h.html#af058de8f1985d1239517801efa8e038a", null ]
];