var os__memheap__drivers_8h =
[
    [ "Heap", "struct_heap.html", null ],
    [ "intHeap", "os__memheap__drivers_8h.html#a341c946d65a72577150d34439477dfe2", null ],
    [ "Heap", "os__memheap__drivers_8h.html#a705af815969c97892c0aaaa658f6c88c", null ],
    [ "AllocStrategy", "os__memheap__drivers_8h.html#adefc48149844c3ceffb7771bbb89d5fb", null ],
    [ "os_getHeapListLength", "os__memheap__drivers_8h.html#a3605704cde0157574ad230b13d4c076b", null ],
    [ "os_initHeaps", "os__memheap__drivers_8h.html#a16154d26c10f906274e90d7a786652a8", null ],
    [ "os_lookupHeap", "os__memheap__drivers_8h.html#aefde63319f6b0d41036f8cfccf2684c6", null ],
    [ "intHeap__", "os__memheap__drivers_8h.html#ab5abd3b149a45c1de26626e02fd13e78", null ]
];