var os__memory_8h =
[
    [ "os_free", "os__memory_8h.html#a345f569e1a9a5d0a6012c76ee1b0f65c", null ],
    [ "os_freeOwnerRestricted", "os__memory_8h.html#ae30934b438eca830815f445a1144a8c2", null ],
    [ "os_freeProcessMemory", "os__memory_8h.html#ac97dfa6f209b8979ac658f93814aa71f", null ],
    [ "os_getAllocationStrategy", "os__memory_8h.html#a6bbc386efe8f2b9ef7d0197239a9ceb7", null ],
    [ "os_getChunkSize", "os__memory_8h.html#ac0d23d85efdcf2dfb01180948214074b", null ],
    [ "os_getFirstByteOfChunk", "os__memory_8h.html#aaa69e86c67d117013f2ff4680c476170", null ],
    [ "os_getMapEntry", "os__memory_8h.html#a9af7a326526068e8016d6e8ad95b4a59", null ],
    [ "os_getMapSize", "os__memory_8h.html#abf1f1d6eeab0f72f6eed9097ce64acc3", null ],
    [ "os_getMapStart", "os__memory_8h.html#afc5ad3e031d4d0ec57645d0886bf5f3f", null ],
    [ "os_getUseSize", "os__memory_8h.html#a2bf045ff7b6b54955473bb02058db3c9", null ],
    [ "os_getUseStart", "os__memory_8h.html#a8c4372f410ab7ac261879ea61b6980ab", null ],
    [ "os_malloc", "os__memory_8h.html#a5644c571680a5c019c91c30bee4d5d7e", null ],
    [ "os_setAllocationStrategy", "os__memory_8h.html#a6e809f1786f114791ae1e8d8abfb39d2", null ]
];