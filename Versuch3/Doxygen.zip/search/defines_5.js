var searchData=
[
  ['heapoffset_460',['HEAPOFFSET',['../defines_8h.html#a46b527dcb3f8c0858e3d77682fc47b73',1,'defines.h']]]
];
