var os__mem__drivers_8c =
[
    [ "initMemoryDevices", "os__mem__drivers_8c.html#a7b4035516f05b473e63dcccfdcbb5ca3", null ],
    [ "initSRAM_internal", "os__mem__drivers_8c.html#a8826af4dce682bd82546f1efc5ee7874", null ],
    [ "readSRAM_internal", "os__mem__drivers_8c.html#adb15019f570eaaef26ffa759a9feedc4", null ],
    [ "writeSRAM_internal", "os__mem__drivers_8c.html#a36530bd7e06adc3f8b056b1caee1c802", null ],
    [ "intSRAM__", "os__mem__drivers_8c.html#aa8eb994dbdb18634b2989d60336a385a", null ]
];