var os__scheduling__strategies_8c =
[
    [ "isAnyProcReady", "os__scheduling__strategies_8c.html#a28b49687a96acfbb30d9ac582fb65cf4", null ],
    [ "os_resetProcessSchedulingInformation", "os__scheduling__strategies_8c.html#aefdd44d05e14f2de4e9853aa83faf98c", null ],
    [ "os_resetSchedulingInformation", "os__scheduling__strategies_8c.html#af63ac803dcc59d7fe7f363c1cf6d5b66", null ],
    [ "os_Scheduler_Even", "os__scheduling__strategies_8c.html#ac02f13255b558aea53e8f1eaa41a9276", null ],
    [ "os_Scheduler_InactiveAging", "os__scheduling__strategies_8c.html#a8d6be305691317a13404a88690a0fd97", null ],
    [ "os_Scheduler_Random", "os__scheduling__strategies_8c.html#a8f2f73d597bc9ff4430b97e51715395d", null ],
    [ "os_Scheduler_RoundRobin", "os__scheduling__strategies_8c.html#acaf98d4ba249f6102399c690de5b53e8", null ],
    [ "os_Scheduler_RunToCompletion", "os__scheduling__strategies_8c.html#a06f1e2042bf3c973f052e13afa101ad4", null ],
    [ "schedulingInfo", "os__scheduling__strategies_8c.html#aadb0e3d669bbca5d4d424f4ba8724848", null ]
];