var os__mem__drivers_8c =
[
    [ "deselect_memory", "os__mem__drivers_8c.html#ad0810cb41540897c98168c15dbd8a929", null ],
    [ "initMemoryDevices", "os__mem__drivers_8c.html#a7b4035516f05b473e63dcccfdcbb5ca3", null ],
    [ "initSRAM_external", "os__mem__drivers_8c.html#ab55b370209e2d049b60ee27982eafd3b", null ],
    [ "initSRAM_internal", "os__mem__drivers_8c.html#a8826af4dce682bd82546f1efc5ee7874", null ],
    [ "readSRAM_external", "os__mem__drivers_8c.html#a4fa256c45a80ac4b5e4eba352afb1304", null ],
    [ "readSRAM_internal", "os__mem__drivers_8c.html#adb15019f570eaaef26ffa759a9feedc4", null ],
    [ "select_memory", "os__mem__drivers_8c.html#a586e4c730a90597fa3b966b59204f8f3", null ],
    [ "set_operation_mode", "os__mem__drivers_8c.html#aeddc5b11419e6ee3b50408ea1cc3ee89", null ],
    [ "transfer_address", "os__mem__drivers_8c.html#aeeae8970c6c5030b4af7867d40a7205c", null ],
    [ "writeSRAM_external", "os__mem__drivers_8c.html#a6a57733985847f954d69d521c2e75e01", null ],
    [ "writeSRAM_internal", "os__mem__drivers_8c.html#a36530bd7e06adc3f8b056b1caee1c802", null ],
    [ "extSRAM__", "os__mem__drivers_8c.html#af1c3e9f7bf5ac9163ab28d4070dc6894", null ],
    [ "intSRAM__", "os__mem__drivers_8c.html#aa8eb994dbdb18634b2989d60336a385a", null ]
];