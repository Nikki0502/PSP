var os__process_8h =
[
    [ "StackPointer", "union_stack_pointer.html", null ],
    [ "Process", "struct_process.html", null ],
    [ "program_linked_list_node", "structprogram__linked__list__node.html", null ],
    [ "REGISTER_AUTOSTART", "os__process_8h.html#a0d6a80de559a050450ba3ed62e461cc2", null ],
    [ "Age", "os__process_8h.html#a797b124dfc6dae58ad80c58d142e5e2a", null ],
    [ "Priority", "os__process_8h.html#a1bb679f7ad1508e942e35da9a0e7eabf", null ],
    [ "Process", "os__process_8h.html#a3b5b0413545e0d4ff600b0a7203e3086", null ],
    [ "ProcessID", "os__process_8h.html#a9ae6ab2a896fd7ccf2c04cd38f9fa6c9", null ],
    [ "ProcessState", "os__process_8h.html#a188e89ad1abd0d38668fb83d89aa8891", null ],
    [ "Program", "os__process_8h.html#a1855c0ea815dd2a3323638f2fda0c38a", null ],
    [ "StackChecksum", "os__process_8h.html#a45db48aaf651fca0006e612d9a3b4b9b", null ],
    [ "StackPointer", "os__process_8h.html#a52b6ead6aa07550bf81e7340e9d50e53", null ],
    [ "ProcessState", "os__process_8h.html#a373a58178f69d5e3e1de7516d105675e", null ],
    [ "os_isRunnable", "os__process_8h.html#a97d3156eb95d3bcb7f81873c41ae4d03", null ],
    [ "autostart_head", "os__process_8h.html#a3bf06243b3e3b8fa8ab5e23fa21d9b76", null ]
];