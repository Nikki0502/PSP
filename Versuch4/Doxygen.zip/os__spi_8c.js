var os__spi_8c =
[
    [ "os_spi_init", "os__spi_8c.html#a44eaf81f9da7b8c38221148f00cee147", null ],
    [ "os_spi_receive", "os__spi_8c.html#a52380983875512356771b8e912c86a65", null ],
    [ "os_spi_send", "os__spi_8c.html#aa2ecb64d76ce8721fdab1a60e6061ebd", null ]
];