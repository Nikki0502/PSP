var searchData=
[
  ['movechunk_343',['moveChunk',['../os__memory_8c.html#a1c8691648bd2d5114b97de7cc2550bc2',1,'os_memory.c']]]
];
